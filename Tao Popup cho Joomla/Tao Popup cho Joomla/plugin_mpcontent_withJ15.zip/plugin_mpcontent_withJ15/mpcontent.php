<?php
// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * plgSystemMPContent
 * 
 * @package 
 * @author DoJoomla
 * @copyright 2008
 * @version $Id$
 * @access public
 */
class plgSystemMPContent extends JPlugin
{

  /**
   * plgSystemMPContent::plgSystemMPContent()
   * 
   * @param mixed $subject
   * @return
   */
	function plgSystemMPContent( &$subject )
	{
		parent::__construct( $subject );
		$this->plugin = &JPluginHelper::getPlugin( 'system', 'mpcontent' );
		$this->params = new JParameter( $this->plugin->params );
	}

  /**
   * plgSystemMPContent::onAfterInitialise()
   * 
   * @return
   */
	function onAfterInitialise()
	{
		# Disable the popup if there is nothing to display
		$id = $this->params->get( 'mpc_content', null );
		if ( !$id ) {
			return;
		}

		# Disable the popup for non-HTML interface (like RSS)
		$document = &JFactory::getDocument();
		$doctype = $document->getType();
		if ( $doctype !== 'html' ) {
			return;
		}

		# Get the required path info
		$uri = &JURI::getInstance();
		$base = str_replace( '/administrator', '', JURI::Base(true) );

		# Determine if we're in the backend
		if ( strpos($uri->_path, '/administrator') === false ) {
			$isadmin = false;
		} else {
			$isadmin = true;
		}

		# Disable the popup on joomla_root/index2.php calls
		if ( $uri->_path == $base . '/index2.php' ) {
			return;
		}

		# Get where the popup will be shown
		$mpc_where = $this->params->get( 'mpc_where', 0 );

		# If we're in the backend and the plugin is configured to display only in frontend
		# then disable the popup
		if ( $isadmin && $mpc_where == 0 ) {
			return;
		}

		# If we're in the frontend and the plugin is configured to display only in backend
		# then disable the popup
		if ( !$isadmin && $mpc_where == 1 ) {
			return;
		}

		# Get how often the popup will be shown
		$mpc_freq = $this->params->get( 'mpc_freq', 1 );

		# Determine if it's time for the popup to be displayed
		if ( $mpc_freq > 0 ) {
			$mpc_next = JRequest::getVar( 'mpc_next_' . $id, null, 'cookie', 'int' );
			if ( $mpc_next > time() ) {
				return;
			}
		}

		# Get the popup's remaining parameters
		$mpc_width = $this->params->get( 'mpc_width', 500 );
		$mpc_height = $this->params->get( 'mpc_height', 500 );
		if ( $mpc_width == 0 )
			$mpc_width = 500;
		if ( $mpc_height == 0 )
			$mpc_height = 500;

		# Display the popup
		$content = "
		function init() {
       		SqueezeBox.fromElement(
			   '" . $base . "/index2.php?option=com_content&view=article&id=$id', 
			   {handler: 'iframe', size: {x: $mpc_width, y: $mpc_height}}
			)
   		};

		if (document.addEventListener) {
			document.addEventListener(\"DOMContentLoaded\", init, false);
		} else {
   			window.onload = init;
		}";

		JHTML::_( 'behavior.modal' );
		$document->addScriptDeclaration( $content, 'text/javascript' );

		#Set coockie as required
		switch ( $mpc_freq ) {
			case 1:
				setcookie( 'mpc_next_' . $id, '', -3600, '/' );
				setcookie( 'mpc_next_' . $id, time() + (60 * 60 * 24 * 365), 0, '/' );
				break;
			case 2:
				setcookie( 'mpc_next_' . $id, '', time() - (60 * 60 * 24 * 365), '/' );
				setcookie( 'mpc_next_' . $id, time() + (60 * 60 * 24 * 365), time() + (60 * 60 * 24 * 365), '/' );
				break;
			default:
				break;
		}
		#End of plugin
		return;
	}
}
